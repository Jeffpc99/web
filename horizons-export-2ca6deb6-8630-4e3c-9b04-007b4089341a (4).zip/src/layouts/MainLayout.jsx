import React, { useState, useEffect } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Menu, X, ChevronDown, Facebook, Instagram, Twitter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const MainLayout = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: 'Inicio', path: '/' },
    { name: 'Nosotros', path: '/nosotros' },
    { name: 'Académico', path: '/academico' },
    { name: 'Admisiones', path: '/admisiones' },
    { name: 'Contacto', path: '/contacto' },
  ];

  return (
    <div className="flex min-h-screen flex-col">
      <header 
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
          isScrolled ? "bg-white/90 backdrop-blur-md shadow-md" : "bg-transparent"
        )}
      >
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <img 
                src="https://storage.googleapis.com/hostinger-horizons-assets-prod/2ca6deb6-8630-4e3c-9b04-007b4089341a/22a086f1a55495a1509081089564576a.png" 
                alt="Colegio Intelectus Logo" 
                className="h-12 w-auto"
              />
              <div className={cn(
                "hidden md:block font-bold text-lg transition-colors",
                isScrolled ? "text-primary" : "text-white"
              )}>
                Colegio Intelectus
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-1">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={cn(
                    "nav-link",
                    location.pathname === link.path && "active",
                    isScrolled ? "text-foreground" : "text-white"
                  )}
                >
                  {link.name}
                </Link>
              ))}
              <Button className="ml-4" size="sm">
                Área de Padres
              </Button>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-primary"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white shadow-lg"
          >
            <div className="container mx-auto px-4 py-3">
              <nav className="flex flex-col space-y-3">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={cn(
                      "py-2 px-4 rounded-md transition-colors",
                      location.pathname === link.path
                        ? "bg-primary/10 text-primary font-medium"
                        : "text-foreground hover:bg-muted"
                    )}
                  >
                    {link.name}
                  </Link>
                ))}
                <Button className="mt-2 w-full">Área de Padres</Button>
              </nav>
            </div>
          </motion.div>
        )}
      </header>

      <main className="flex-grow pt-16">
        <Outlet />
      </main>

      <footer className="bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img 
                  src="https://storage.googleapis.com/hostinger-horizons-assets-prod/2ca6deb6-8630-4e3c-9b04-007b4089341a/22a086f1a55495a1509081089564576a.png" 
                  alt="Colegio Intelectus Logo" 
                  className="h-12 w-auto"
                />
                <span className="font-bold text-lg">Colegio Intelectus</span>
              </div>
              <p className="text-gray-400 mb-4">
                Educación de calidad con valores para formar líderes del mañana.
              </p>
              <p className="text-gray-400">R.D.R. N° 10729</p>
            </div>

            <div>
              <span className="font-bold text-lg block mb-4">Enlaces Rápidos</span>
              <ul className="space-y-2">
                {navLinks.map((link) => (
                  <li key={link.path}>
                    <Link to={link.path} className="text-gray-400 hover:text-secondary transition-colors">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <span className="font-bold text-lg block mb-4">Contáctanos</span>
              <p className="text-gray-400 mb-2">Av. Educación 123, Lima</p>
              <p className="text-gray-400 mb-2">info@colegiointelectus.edu.pe</p>
              <p className="text-gray-400 mb-4">(01) 123-4567</p>
              
              <div className="flex space-x-4 mt-4">
                <a href="#" className="text-gray-400 hover:text-secondary transition-colors">
                  <Facebook size={20} />
                </a>
                <a href="#" className="text-gray-400 hover:text-secondary transition-colors">
                  <Instagram size={20} />
                </a>
                <a href="#" className="text-gray-400 hover:text-secondary transition-colors">
                  <Twitter size={20} />
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
            <p>© {new Date().getFullYear()} Colegio Particular Intelectus. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default MainLayout;