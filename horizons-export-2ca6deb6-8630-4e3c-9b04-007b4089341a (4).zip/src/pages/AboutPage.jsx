
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Target, Heart, BookOpen } from 'lucide-react';
import PageTransition from '@/components/PageTransition';
import SectionHeading from '@/components/SectionHeading';
import AboutHero from '@/components/about/AboutHero';
import HistorySection from '@/components/about/HistorySection';
import PhilosophySection from '@/components/about/PhilosophySection';
import TeamSection from '@/components/about/TeamSection';
import InfrastructureSection from '@/components/about/InfrastructureSection';

const teamMembers = [
  {
    name: "Ing° Richard Grau Chávez",
    role: "Promotor",
    bio: "Comprometido con la visión de una educación de calidad y excelencia.",
    image: "Hombre profesional con experiencia en gestión y desarrollo de proyectos educativos"
  },
  {
    name: "Lic. Ellis Hidalgo Mendoza",
    role: "Promotor",
    bio: "Apasionada por la formación integral y el desarrollo del potencial humano.",
    image: "Mujer profesional con vocación por la educación y el bienestar estudiantil"
  },
  {
    name: "Lic. Gilbert Iman Silupu",
    role: "Director",
    bio: "Liderando la institución hacia la excelencia académica y la innovación pedagógica.",
    image: "Hombre con experiencia directiva en instituciones educativas, inspirando confianza"
  },
  {
    name: "Emilio Huayama Zapata",
    role: "Coordinador Académico",
    bio: "Dedicado a la mejora continua de los procesos de enseñanza y aprendizaje.",
    image: "Profesional de la educación enfocado en la planificación y seguimiento académico"
  },
  {
    name: "José Manuel Estela",
    role: "Coordinador Académico",
    bio: "Experto en estrategias pedagógicas y desarrollo curricular.",
    image: "Educador con experiencia en coordinación y desarrollo de programas académicos"
  },
  {
    name: "Miguel Enrique Pacherres Alamo",
    role: "Coordinador de Actividades",
    bio: "Encargado de fomentar un ambiente escolar dinámico y enriquecedor.",
    image: "Profesional dinámico organizando eventos y actividades para estudiantes"
  }
];

const facilities = [
  {
    title: "Aulas Modernas",
    description: "Espacios amplios, bien iluminados y equipados para un aprendizaje efectivo.",
    image: "Aula moderna con pizarra interactiva, pupitres ergonómicos y amplia iluminación natural"
  },
  {
    title: "Laboratorios",
    description: "Laboratorios de ciencias e informática para el aprendizaje práctico y experimental.",
    image: "Laboratorio de ciencias con equipos modernos, microscopios y estaciones de trabajo para estudiantes"
  },
  {
    title: "Biblioteca",
    description: "Amplia colección de libros y recursos para fomentar la investigación y el amor por la lectura.",
    image: "Biblioteca escolar moderna con estanterías de libros, mesas de estudio y área de computadoras"
  },
  {
    title: "Áreas Deportivas",
    description: "Espacios para el desarrollo físico y la práctica de deportes.",
    image: "Cancha deportiva multiuso con estudiantes practicando diferentes deportes en un ambiente seguro"
  },
  {
    title: "Espacios Recreativos",
    description: "Zonas para el esparcimiento y la convivencia entre estudiantes.",
    image: "Patio escolar con áreas verdes y juegos donde los estudiantes interactúan"
  },
  {
    title: "Salón de Actos",
    description: "Espacio para eventos culturales, ceremonias y presentaciones.",
    image: "Auditorio escolar con escenario, butacas cómodas y equipo audiovisual moderno"
  }
];

const AboutPage = () => {
  const schoolHistory = {
    main: "La Institución Educativa Privada “Intelectus” de Castilla, ubicada en Calle Los Rosales Mz Q lote 12 de la Urbanización Miraflores del distrito de Castilla fue creada oficialmente el 17 de diciembre del año 2019 con Resolución Directoral Regional N° 10729 emitida por la Dirección Regional de Educación de Piura, atendiendo en una primera etapa al nivel de Educación Secundaria de Menores bajo el LEMA: AUTODISCIPLINA, ESFUERZO Y PERSEVERANCIA; la misma que desde su origen tuvo la misión de preparar a la juventud piurano – castellana en el aspecto científico y humanístico, como también en la enseñanza de la educación preuniversitaria, aspectos que hasta la fecha viene conservando en su esencia.",
    current: "En su sexto año de funcionamiento, la Institución Educativa Privada “Intelectus” es una institución joven que trabaja por brindar una educación de mejor calidad, alta exigencia y competitividad académica, bajo la gestión de sus promotores: Ing° Richard Grau Chávez y Lic. Ellis Hidalgo Mendoza; así como también de su Director actual: Lic. Gilbert Iman Silupu, coordinadores académicos: Emilio Huayama Zapata, José Manuel Estela y el coordinador de actividades Miguel Enrique Pacherres Alamo.",
    legacy: "Nuestra institución sigue fiel a su visión original, adaptándose a los cambios educativos y tecnológicos, pero manteniendo siempre nuestra esencia: el compromiso con la formación integral de líderes para el futuro.",
    imageAlt: "Fachada del Colegio Intelectus o estudiantes en actividad",
    imageUrl: "https://images.unsplash.com/photo-1700049015282-067413ba639e"
  };

  const philosophy = {
    mission: "Preparar a la juventud piurano – castellana en el aspecto científico y humanístico, y en la enseñanza de la educación preuniversitaria, formando estudiantes íntegros con sólidos conocimientos y valores.",
    vision: "Ser reconocidos como una institución educativa de referencia por nuestra alta exigencia, competitividad académica y la formación de líderes con pensamiento crítico y compromiso social.",
    values: ["Autodisciplina", "Esfuerzo", "Perseverancia", "Respeto", "Responsabilidad", "Honestidad"]
  };

  return (
    <PageTransition>
      <AboutHero />
      <HistorySection history={schoolHistory} />
      <PhilosophySection philosophy={philosophy} />
      <TeamSection teamMembers={teamMembers} />
      <InfrastructureSection facilities={facilities} />
    </PageTransition>
  );
};

export default AboutPage;
