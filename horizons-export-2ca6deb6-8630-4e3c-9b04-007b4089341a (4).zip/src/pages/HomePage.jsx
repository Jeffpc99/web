import React from 'react';
import PageTransition from '@/components/PageTransition';
import HeroSection from '@/components/home/HeroSection.jsx';
import FeaturesSection from '@/components/home/FeaturesSection.jsx';
import HomeAboutSection from '@/components/home/HomeAboutSection.jsx';
import AcademicProgramsSection from '@/components/home/AcademicProgramsSection.jsx';
import TestimonialsSection from '@/components/home/TestimonialsSection.jsx';
import CTASection from '@/components/home/CTASection.jsx';

const HomePage = () => {
  const features = [
    {
      icon: "BookOpen",
      title: "Excelencia Académica",
      description: "Programa educativo de alto nivel con metodologías innovadoras y enfoque preuniversitario."
    },
    {
      icon: "Users",
      title: "Formación en Valores",
      description: "Educamos con principios como autodisciplina, esfuerzo y perseverancia."
    },
    {
      icon: "Award",
      title: "Docentes Calificados",
      description: "Equipo de profesionales comprometidos con la educación de calidad y la preparación de los estudiantes."
    },
    {
      icon: "Calendar",
      title: "Desarrollo Integral",
      description: "Fomentamos el crecimiento científico, humanístico y personal de cada alumno."
    }
  ];

  const academicPrograms = [
    {
      title: "Educación Secundaria",
      description: "Preparación científica y humanística, con énfasis en la formación preuniversitaria.",
      image: "Adolescentes en un laboratorio de ciencias realizando experimentos con equipos modernos",
      imageUrl: "https://images.unsplash.com/photo-1696041757866-f19a8e46fab1" 
    },
    {
      title: "Talleres Complementarios",
      description: "Actividades que refuerzan el aprendizaje y desarrollan habilidades diversas.",
      image: "Estudiantes participando en talleres artísticos o deportivos en el colegio",
      imageUrl: "https://images.unsplash.com/photo-1542744095-291d1f67b221"
    },
    {
      title: "Orientación Vocacional",
      description: "Apoyo a los estudiantes en la elección de su futuro profesional y académico.",
      image: "Un orientador conversando con un grupo de estudiantes sobre sus opciones de carrera",
      imageUrl: "https://images.unsplash.com/photo-1517048676732-d65bc937f952"
    }
  ];

  const testimonials = [
    {
      quote: "Intelectus ha sido clave en la preparación de mi hijo para la universidad. Su exigencia académica es notable.",
      author: "Ana Pérez",
      role: "Madre de familia"
    },
    {
      quote: "Los profesores son muy dedicados y el lema de autodisciplina y esfuerzo realmente se vive en el colegio.",
      author: "Luis Torres",
      role: "Padre de familia"
    },
    {
      quote: "Gracias a la formación en Intelectus, me siento preparado para los retos universitarios y profesionales.",
      author: "Carlos Vera",
      role: "Ex-alumno"
    }
  ];


  return (
    <PageTransition>
      <HeroSection 
        title="Colegio Intelectus: Autodisciplina, Esfuerzo y Perseverancia"
        subtitle="Formando líderes con valores e inteligencia para un futuro exitoso."
        imageAlt="Estudiantes del Colegio Intelectus en una actividad académica"
        imageUrl="https://images.unsplash.com/photo-1701701046353-89f1a671c24b"
      />
      <FeaturesSection features={features} />
      <HomeAboutSection 
        title="Nuestra Institución"
        subtitle="Comprometidos con la excelencia educativa desde 2019"
        text1="Fundado con la misión de preparar a la juventud en el aspecto científico, humanístico y preuniversitario."
        text2="En nuestro sexto año, continuamos brindando una educación de calidad, con alta exigencia y competitividad académica."
        imageAlt="Instalaciones del Colegio Intelectus"
        imageUrl="https://images.unsplash.com/photo-1695787845331-4c06f963c37e"
      />
      <AcademicProgramsSection programs={academicPrograms} />
      <TestimonialsSection testimonials={testimonials} />
      <CTASection 
        title="¿Listo para unirte a la familia Intelectus?"
        subtitle="Descubre nuestro proceso de admisión y sé parte de una institución que valora la autodisciplina, el esfuerzo y la perseverancia."
      />
    </PageTransition>
  );
};

export default HomePage;