
import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Award, Clock, Calendar, Users, Lightbulb } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PageTransition from '@/components/PageTransition';
import SectionHeading from '@/components/SectionHeading';

const AcademicPage = () => {
  return (
    <PageTransition>
      {/* Hero Section */}
      <section className="relative bg-primary py-20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/70"></div>
        <div className="container mx-auto px-4 py-16 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1
              className="text-4xl md:text-5xl font-bold text-white mb-6"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Programa Académico
            </motion.h1>
            <motion.p
              className="text-xl text-white/90"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Conoce nuestra propuesta educativa integral, diseñada para desarrollar el máximo potencial de cada estudiante.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Educational Model */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <SectionHeading 
                title="Nuestro Modelo Educativo" 
                subtitle="Una propuesta pedagógica innovadora y centrada en el estudiante"
              />
              <p className="mb-6 text-gray-600">
                En Colegio Intelectus, implementamos un modelo educativo que combina lo mejor de las metodologías tradicionales con enfoques pedagógicos innovadores, adaptados a las necesidades del siglo XXI.
              </p>
              <p className="mb-6 text-gray-600">
                Nuestro enfoque se basa en el desarrollo de competencias, el aprendizaje significativo y la formación integral, considerando las dimensiones cognitiva, socioemocional, física y ética de cada estudiante.
              </p>
              <p className="text-gray-600">
                Trabajamos con grupos reducidos que permiten una atención personalizada, respetando los ritmos y estilos de aprendizaje de cada alumno, y fomentando su autonomía y pensamiento crítico.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <img  alt="Modelo educativo del Colegio Intelectus" className="rounded-lg shadow-xl" src="https://images.unsplash.com/photo-1694532409273-b26e2ce266ea" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Educational Levels */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="Niveles Educativos" 
            subtitle="Una formación completa desde los primeros años hasta la preparación para la universidad"
            centered={true}
          />
          
          <div className="mt-12 space-y-16">
            {/* Nivel Inicial */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="order-2 md:order-1"
              >
                <h3 className="text-3xl font-bold mb-4 text-primary">Nivel Inicial</h3>
                <p className="mb-6 text-gray-600">
                  En esta etapa fundamental, brindamos un ambiente acogedor y estimulante donde los niños desarrollan sus primeras habilidades sociales, emocionales y cognitivas a través del juego y la exploración.
                </p>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <BookOpen className="h-5 w-5 text-secondary mr-2 mt-1" />
                    <span className="text-gray-600">Estimulación temprana y desarrollo de habilidades motoras</span>
                  </li>
                  <li className="flex items-start">
                    <BookOpen className="h-5 w-5 text-secondary mr-2 mt-1" />
                    <span className="text-gray-600">Iniciación a la lectoescritura y pensamiento lógico-matemático</span>
                  </li>
                  <li className="flex items-start">
                    <BookOpen className="h-5 w-5 text-secondary mr-2 mt-1" />
                    <span className="text-gray-600">Desarrollo socioemocional y adaptación al entorno escolar</span>
                  </li>
                </ul>
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>Horario: 8:00 am - 1:00 pm</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    <span>Edades: 3 a 5 años</span>
                  </div>
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="order-1 md:order-2"
              >
                <img  alt="Nivel Inicial en Colegio Intelectus" className="rounded-lg shadow-xl" src="https://images.unsplash.com/photo-1693920615602-ff4d3a2df3a3" />
              </motion.div>
            </div>

            {/* Nivel Primaria */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <img  alt="Nivel Primaria en Colegio Intelectus" className="rounded-lg shadow-xl" src="https://images.unsplash.com/photo-1698193898859-b452f249a45c" />
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <h3 className="text-3xl font-bold mb-4 text-primary">Nivel Primaria</h3>
                <p className="mb-6 text-gray-600">
                  Durante esta etapa crucial, consolidamos las bases del conocimiento y desarrollamos habilidades fundamentales para el aprendizaje continuo, fomentando la curiosidad, la investigación y el trabajo colaborativo.
                </p>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <BookOpen className="h-5 w-5 text-secondary mr-2 mt-1" />
                    <span className="text-gray-600">Desarrollo de competencias comunicativas y matemáticas</span>
                  </li>
                  <li className="flex items-start">
                    <BookOpen className="h-5 w-5 text-secondary mr-2 mt-1" />
                    <span className="text-gray-600">Formación en ciencias, historia y geografía con enfoque práctico</span>
                  </li>
                  <li className="flex items-start">
                    <BookOpen className="h-5 w-5 text-secondary mr-2 mt-1" />
                    <span className="text-gray-600">Inglés intensivo y formación artística complementaria</span>
                  </li>
                </ul>
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>Horario: 7:30 am - 2:30 pm</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    <span>Grados: 1° a 6°</span>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Nivel Secundaria */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="order-2 md:order-1"
              >
                <h3 className="text-3xl font-bold mb-4 text-primary">Nivel Secundaria</h3>
                <p className="mb-6 text-gray-600">
                  En esta etapa final, preparamos a nuestros estudiantes para los desafíos académicos y personales que enfrentarán en la universidad y en su vida profesional, con un enfoque en el desarrollo de competencias del siglo XXI.
                </p>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <BookOpen className="h-5 w-5 text-secondary mr-2 mt-1" />
                    <span className="text-gray-600">Formación académica avanzada en todas las áreas del conocimiento</span>
                  </li>
                  <li className="flex items-start">
                    <BookOpen className="h-5 w-5 text-secondary mr-2 mt-1" />
                    <span className="text-gray-600">Desarrollo de pensamiento crítico, creatividad y resolución de problemas</span>
                  </li>
                  <li className="flex items-start">
                    <BookOpen className="h-5 w-5 text-secondary mr-2 mt-1" />
                    <span className="text-gray-600">Orientación vocacional y preparación para la vida universitaria</span>
                  </li>
                </ul>
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>Horario: 7:30 am - 3:00 pm</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    <span>Grados: 1° a 5°</span>
                  </div>
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="order-1 md:order-2"
              >
                <img  alt="Nivel Secundaria en Colegio Intelectus" className="rounded-lg shadow-xl" src="https://images.unsplash.com/photo-1618053238059-cc7761222f2a" />
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Extracurricular Activities */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="Actividades Extracurriculares" 
            subtitle="Complementamos la formación académica con una amplia oferta de talleres"
            centered={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            {[
              {
                title: "Deportes",
                description: "Fútbol, básquet, vóley, atletismo y natación para el desarrollo físico y trabajo en equipo.",
                icon: <Award className="h-10 w-10 text-secondary" />,
                image: "Estudiantes practicando diferentes deportes en las instalaciones deportivas del colegio"
              },
              {
                title: "Arte y Cultura",
                description: "Música, danza, teatro, pintura y coro para el desarrollo de la sensibilidad artística.",
                icon: <Lightbulb className="h-10 w-10 text-secondary" />,
                image: "Estudiantes participando en actividades artísticas como pintura, música y teatro"
              },
              {
                title: "Ciencia y Tecnología",
                description: "Robótica, programación, club de ciencias y matemáticas para potenciar habilidades STEM.",
                icon: <BookOpen className="h-10 w-10 text-secondary" />,
                image: "Estudiantes trabajando en proyectos de robótica y programación con equipos tecnológicos"
              },
              {
                title: "Idiomas",
                description: "Inglés avanzado, francés y mandarín para una formación multilingüe.",
                icon: <Users className="h-10 w-10 text-secondary" />,
                image: "Estudiantes en un laboratorio de idiomas practicando diferentes lenguas con tecnología especializada"
              },
              {
                title: "Liderazgo",
                description: "Debate, oratoria y emprendimiento para desarrollar habilidades de liderazgo.",
                icon: <Calendar className="h-10 w-10 text-secondary" />,
                image: "Estudiantes participando en un debate o presentación frente a un público en el auditorio escolar"
              },
              {
                title: "Responsabilidad Social",
                description: "Proyectos comunitarios y voluntariado para fomentar la solidaridad y el compromiso social.",
                icon: <Users className="h-10 w-10 text-secondary" />,
                image: "Estudiantes participando en actividades de voluntariado y proyectos de ayuda comunitaria"
              }
            ].map((activity, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full overflow-hidden card-hover">
                  <div className="h-48 overflow-hidden">
                    <img  alt={activity.title} className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1694388001616-1176f534d72f" />
                  </div>
                  <CardHeader>
                    <div className="mb-4">{activity.icon}</div>
                    <CardTitle>{activity.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">{activity.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Academic Calendar */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="Calendario Académico" 
            subtitle="Planificación anual de actividades escolares"
            centered={true}
          />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="bg-white p-8 rounded-lg shadow-lg mt-12"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">Primer Semestre</h3>
                <ul className="space-y-4">
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white text-sm font-medium">
                        Mar
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Inicio del año escolar</p>
                      <p className="text-sm text-gray-500">Primera semana de marzo</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white text-sm font-medium">
                        Abr
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Semana Santa</p>
                      <p className="text-sm text-gray-500">Según calendario litúrgico</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white text-sm font-medium">
                        May
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Día de la Madre</p>
                      <p className="text-sm text-gray-500">Segunda semana de mayo</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white text-sm font-medium">
                        Jun
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Día del Padre</p>
                      <p className="text-sm text-gray-500">Tercera semana de junio</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white text-sm font-medium">
                        Jul
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Vacaciones de medio año</p>
                      <p className="text-sm text-gray-500">Últimas dos semanas de julio</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">Segundo Semestre</h3>
                <ul className="space-y-4">
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-secondary text-white text-sm font-medium">
                        Ago
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Reinicio de clases</p>
                      <p className="text-sm text-gray-500">Primera semana de agosto</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-secondary text-white text-sm font-medium">
                        Sep
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Semana de la Primavera</p>
                      <p className="text-sm text-gray-500">Tercera semana de septiembre</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-secondary text-white text-sm font-medium">
                        Oct
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Semana de la Ciencia</p>
                      <p className="text-sm text-gray-500">Segunda semana de octubre</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-secondary text-white text-sm font-medium">
                        Nov
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Aniversario del colegio</p>
                      <p className="text-sm text-gray-500">Primera semana de noviembre</p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="mr-4 flex-shrink-0">
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-secondary text-white text-sm font-medium">
                        Dic
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">Clausura del año escolar</p>
                      <p className="text-sm text-gray-500">Segunda semana de diciembre</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div className="mt-8 text-center">
              <Button>Descargar calendario completo</Button>
            </div>
          </motion.div>
        </div>
      </section>
    </PageTransition>
  );
};

export default AcademicPage;
