
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, FileText, Calendar, DollarSign, HelpCircle, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PageTransition from '@/components/PageTransition';
import SectionHeading from '@/components/SectionHeading';

const AdmissionsPage = () => {
  return (
    <PageTransition>
      {/* Hero Section */}
      <section className="relative bg-primary py-20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/70"></div>
        <div className="container mx-auto px-4 py-16 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1
              className="text-4xl md:text-5xl font-bold text-white mb-6"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Proceso de Admisión
            </motion.h1>
            <motion.p
              className="text-xl text-white/90"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Forma parte de nuestra comunidad educativa y brinda a tus hijos una educación de excelencia.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="¿Por qué elegir Colegio Intelectus?" 
            subtitle="Razones que nos distinguen como una institución educativa de excelencia"
            centered={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <ul className="space-y-6">
                {[
                  {
                    title: "Excelencia Académica",
                    description: "Nuestros estudiantes obtienen resultados sobresalientes en evaluaciones nacionales e internacionales."
                  },
                  {
                    title: "Formación Integral",
                    description: "Desarrollamos todas las dimensiones de la persona: intelectual, física, social, emocional y ética."
                  },
                  {
                    title: "Atención Personalizada",
                    description: "Grupos reducidos que permiten un seguimiento cercano del progreso de cada estudiante."
                  },
                  {
                    title: "Infraestructura Moderna",
                    description: "Instalaciones diseñadas para potenciar el aprendizaje y el desarrollo integral."
                  }
                ].map((item, index) => (
                  <li key={index} className="flex">
                    <CheckCircle className="h-6 w-6 text-secondary mr-3 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-lg font-bold mb-1">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <ul className="space-y-6">
                {[
                  {
                    title: "Educación Bilingüe",
                    description: "Programa de inglés intensivo que prepara a nuestros estudiantes para un mundo globalizado."
                  },
                  {
                    title: "Tecnología Educativa",
                    description: "Incorporamos herramientas tecnológicas que potencian el proceso de enseñanza-aprendizaje."
                  },
                  {
                    title: "Valores Sólidos",
                    description: "Formamos personas íntegras, con principios éticos y compromiso social."
                  },
                  {
                    title: "Comunidad Educativa",
                    description: "Fomentamos la participación activa de las familias en el proceso educativo."
                  }
                ].map((item, index) => (
                  <li key={index} className="flex">
                    <CheckCircle className="h-6 w-6 text-secondary mr-3 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-lg font-bold mb-1">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Admission Process */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="Proceso de Admisión" 
            subtitle="Conoce los pasos para formar parte de nuestra comunidad educativa"
            centered={true}
          />
          
          <div className="mt-12 relative">
            <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-gray-200 transform -translate-x-1/2"></div>
            
            {[
              {
                step: "Paso 1",
                title: "Solicitud de Información",
                description: "Completa el formulario de contacto o visítanos para recibir información detallada sobre nuestro proyecto educativo, requisitos y costos.",
                icon: <FileText className="h-8 w-8 text-white" />
              },
              {
                step: "Paso 2",
                title: "Visita Guiada",
                description: "Agenda una visita a nuestras instalaciones para conocer la infraestructura, metodología y resolver todas tus dudas.",
                icon: <Calendar className="h-8 w-8 text-white" />
              },
              {
                step: "Paso 3",
                title: "Presentación de Documentos",
                description: "Entrega la documentación requerida: formulario de admisión, documentos de identidad, informes académicos previos y otros según el nivel.",
                icon: <FileText className="h-8 w-8 text-white" />
              },
              {
                step: "Paso 4",
                title: "Evaluación Diagnóstica",
                description: "El estudiante participa en una evaluación diagnóstica acorde a su edad para identificar sus fortalezas y áreas de oportunidad.",
                icon: <HelpCircle className="h-8 w-8 text-white" />
              },
              {
                step: "Paso 5",
                title: "Entrevista Familiar",
                description: "Los padres y el estudiante participan en una entrevista con nuestro equipo psicopedagógico para conocer expectativas y necesidades.",
                icon: <Users className="h-8 w-8 text-white" />
              },
              {
                step: "Paso 6",
                title: "Resultados y Matrícula",
                description: "Comunicamos los resultados del proceso y, en caso favorable, se procede con el proceso de matrícula y bienvenida a la familia.",
                icon: <CheckCircle className="h-8 w-8 text-white" />
              }
            ].map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative mb-12"
              >
                <div className={`md:grid md:grid-cols-2 gap-8 items-center ${index % 2 !== 0 ? 'md:rtl' : ''}`}>
                  <div className={`${index % 2 !== 0 ? 'md:text-right' : ''} md:ltr`}>
                    <div className="bg-white p-6 rounded-lg shadow-lg">
                      <span className="inline-block px-3 py-1 bg-primary text-white text-sm font-medium rounded-full mb-3">
                        {step.step}
                      </span>
                      <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                      <p className="text-gray-600">{step.description}</p>
                    </div>
                  </div>
                  <div className="hidden md:block"></div>
                </div>
                <div className="hidden md:flex absolute top-6 left-1/2 transform -translate-x-1/2 items-center justify-center h-12 w-12 rounded-full bg-primary shadow-lg">
                  {step.icon}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Requirements */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="Requisitos" 
            subtitle="Documentación necesaria para el proceso de admisión"
            centered={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            {[
              {
                title: "Nivel Inicial",
                requirements: [
                  "Partida de nacimiento original",
                  "Copia de DNI del estudiante",
                  "Copia de DNI de ambos padres",
                  "Ficha de matrícula anterior (si procede)",
                  "Libreta de notas del año anterior (si procede)",
                  "Constancia de no adeudo (si procede)",
                  "4 fotografías tamaño carnet"
                ],
                icon: <FileText className="h-10 w-10 text-primary" />
              },
              {
                title: "Nivel Primaria",
                requirements: [
                  "Partida de nacimiento original",
                  "Copia de DNI del estudiante",
                  "Copia de DNI de ambos padres",
                  "Certificado de estudios de años anteriores",
                  "Ficha de matrícula anterior",
                  "Libreta de notas del año anterior",
                  "Constancia de no adeudo",
                  "Constancia de conducta",
                  "4 fotografías tamaño carnet"
                ],
                icon: <FileText className="h-10 w-10 text-primary" />
              },
              {
                title: "Nivel Secundaria",
                requirements: [
                  "Partida de nacimiento original",
                  "Copia de DNI del estudiante",
                  "Copia de DNI de ambos padres",
                  "Certificado de estudios de años anteriores",
                  "Ficha de matrícula anterior",
                  "Libreta de notas del año anterior",
                  "Constancia de no adeudo",
                  "Constancia de conducta",
                  "4 fotografías tamaño carnet"
                ],
                icon: <FileText className="h-10 w-10 text-primary" />
              }
            ].map((level, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader className="text-center">
                    <div className="mx-auto mb-4">{level.icon}</div>
                    <CardTitle>{level.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {level.requirements.map((req, idx) => (
                        <li key={idx} className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-secondary mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-600">{req}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Investment */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="Inversión Educativa" 
            subtitle="Información sobre costos y modalidades de pago"
            centered={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            {[
              {
                title: "Nivel Inicial",
                matricula: "S/. 850",
                pension: "S/. 850",
                icon: <DollarSign className="h-10 w-10 text-white" />
              },
              {
                title: "Nivel Primaria",
                matricula: "S/. 950",
                pension: "S/. 950",
                icon: <DollarSign className="h-10 w-10 text-white" />
              },
              {
                title: "Nivel Secundaria",
                matricula: "S/. 1050",
                pension: "S/. 1050",
                icon: <DollarSign className="h-10 w-10 text-white" />
              }
            ].map((level, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full border-none shadow-lg overflow-hidden">
                  <div className="bg-primary text-white p-6 text-center">
                    <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-white/20 mb-4">
                      {level.icon}
                    </div>
                    <h3 className="text-2xl font-bold">{level.title}</h3>
                  </div>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-500 mb-1">Matrícula</p>
                        <p className="text-3xl font-bold text-primary">{level.matricula}</p>
                        <p className="text-sm text-gray-500 mt-1">Pago anual</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-500 mb-1">Pensión Mensual</p>
                        <p className="text-3xl font-bold text-primary">{level.pension}</p>
                        <p className="text-sm text-gray-500 mt-1">10 cuotas al año</p>
                      </div>
                    </div>
                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-secondary mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-600">Material educativo incluido</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-secondary mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-600">Plataforma virtual</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-secondary mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-600">Talleres extracurriculares</span>
                        </li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-6">
              * Los precios pueden estar sujetos a variaciones. Consulta por descuentos por hermanos y pronto pago.
            </p>
            <Button size="lg">Solicitar información detallada</Button>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="Preguntas Frecuentes" 
            subtitle="Resolvemos tus dudas sobre el proceso de admisión"
            centered={true}
          />
          
          <div className="mt-12 max-w-3xl mx-auto">
            {[
              {
                question: "¿Cuándo inicia el proceso de admisión?",
                answer: "El proceso de admisión para el año escolar 2025 inicia en agosto de 2024. Sin embargo, aceptamos solicitudes durante todo el año, sujetas a disponibilidad de vacantes."
              },
              {
                question: "¿Qué sucede si mi hijo/a no aprueba la evaluación diagnóstica?",
                answer: "La evaluación diagnóstica no es eliminatoria, sino una herramienta para conocer el nivel académico del estudiante y poder brindarle el apoyo necesario. En casos específicos, podríamos recomendar nivelación o apoyo adicional."
              },
              {
                question: "¿Ofrecen becas o descuentos?",
                answer: "Sí, contamos con un programa de becas por excelencia académica y descuentos por hermanos. También ofrecemos facilidades de pago y descuentos por pronto pago anual."
              },
              {
                question: "¿Qué servicios adicionales ofrecen?",
                answer: "Ofrecemos servicios de comedor escolar, movilidad, talleres extracurriculares, asesoría psicopedagógica y programa de reforzamiento académico."
              },
              {
                question: "¿Cómo es el proceso de adaptación para estudiantes nuevos?",
                answer: "Contamos con un programa de inducción y adaptación que incluye actividades de integración, acompañamiento personalizado y seguimiento cercano durante las primeras semanas."
              }
            ].map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="mb-6"
              >
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-lg font-bold mb-3 flex items-start">
                    <HelpCircle className="h-5 w-5 text-primary mr-2 mt-0.5 flex-shrink-0" />
                    <span>{faq.question}</span>
                  </h3>
                  <p className="text-gray-600 ml-7">{faq.answer}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h2
              className="text-3xl md:text-4xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              ¿Listo para iniciar el proceso de admisión?
            </motion.h2>
            <motion.p
              className="text-xl text-white/90 mb-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Contáctanos hoy mismo y comienza el camino hacia una educación de excelencia para tus hijos.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="flex flex-wrap justify-center gap-4"
            >
              <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                Solicitar información
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/20">
                Agendar una visita
              </Button>
            </motion.div>
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

export default AdmissionsPage;
