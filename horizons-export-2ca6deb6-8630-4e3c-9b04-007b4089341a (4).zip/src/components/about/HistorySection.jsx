
import React from 'react';
import { motion } from 'framer-motion';
import SectionHeading from '@/components/SectionHeading';

const HistorySection = ({ history }) => {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <SectionHeading 
              title="Nuestra Historia" 
              subtitle="Un camino de autodisciplina, esfuerzo y perseverancia"
            />
            <p className="mb-6 text-gray-600">
              {history.main}
            </p>
            <p className="mb-6 text-gray-600">
              {history.current}
            </p>
            <p className="text-gray-600">
              {history.legacy}
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <img  alt={history.imageAlt} className="rounded-lg shadow-xl" src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HistorySection;
