
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Target, BookOpen, Heart } from 'lucide-react';
import SectionHeading from '@/components/SectionHeading';

const PhilosophySection = ({ philosophy }) => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <SectionHeading 
          title="Nuestra Filosofía" 
          subtitle="Los pilares que guían nuestro trabajo educativo"
          centered={true}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="bg-white p-8 rounded-lg shadow-lg"
          >
            <div className="mb-6 text-center">
              <Target className="h-16 w-16 text-primary mx-auto" />
            </div>
            <h3 className="text-2xl font-bold mb-4 text-center">Misión</h3>
            <p className="text-gray-600">
              {philosophy.mission}
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-white p-8 rounded-lg shadow-lg"
          >
            <div className="mb-6 text-center">
              <BookOpen className="h-16 w-16 text-primary mx-auto" />
            </div>
            <h3 className="text-2xl font-bold mb-4 text-center">Visión</h3>
            <p className="text-gray-600">
              {philosophy.vision}
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-white p-8 rounded-lg shadow-lg"
          >
            <div className="mb-6 text-center">
              <Heart className="h-16 w-16 text-primary mx-auto" />
            </div>
            <h3 className="text-2xl font-bold mb-4 text-center">Valores</h3>
            <ul className="space-y-3">
              {philosophy.values.map((value, index) => (
                <li key={index} className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-secondary mr-2" />
                  <span className="text-gray-600">{value}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default PhilosophySection;
