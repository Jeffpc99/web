
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import SectionHeading from '@/components/SectionHeading';
import { Link } from 'react-router-dom';

const HomeAboutSection = ({ title, subtitle, text1, text2, imageAlt, imageUrl }) => {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <img  alt={imageAlt} className="rounded-lg shadow-xl" src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <SectionHeading 
              title={title}
              subtitle={subtitle}
            />
            <p className="mb-6 text-gray-600">
              {text1}
            </p>
            <p className="mb-6 text-gray-600">
              {text2}
            </p>
            <Button className="mt-4" asChild>
              <Link to="/nosotros">
                Conoce más sobre nosotros <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HomeAboutSection;
