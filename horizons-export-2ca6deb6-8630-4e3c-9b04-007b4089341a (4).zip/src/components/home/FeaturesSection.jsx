
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import SectionHeading from '@/components/SectionHeading';
import { BookOpen, Users, Award, Calendar } from 'lucide-react';

const iconMap = {
  BookOpen: BookOpen,
  Users: Users,
  Award: Award,
  Calendar: Calendar,
};

const FeaturesSection = ({ features }) => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <SectionHeading 
          title="¿Por qué elegir Intelectus?" 
          subtitle="Ofrecemos una experiencia educativa única centrada en el desarrollo integral."
          centered={true}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const IconComponent = iconMap[feature.icon];
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full card-hover border-none shadow-md hover:shadow-primary/20">
                  <CardHeader>
                    {IconComponent && <div className="mb-4"><IconComponent className="h-10 w-10 text-secondary" /></div>}
                    <CardTitle>{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
