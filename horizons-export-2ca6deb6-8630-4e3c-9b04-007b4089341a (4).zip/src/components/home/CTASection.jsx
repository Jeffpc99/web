import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const CTASection = ({ title, subtitle }) => {
  return (
    <section className="relative py-20 bg-primary hero-pattern">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-secondary/70 opacity-90"></div>
      <div className="container mx-auto px-4 relative z-10 text-center">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-3xl md:text-4xl font-bold text-white mb-4"
        >
          {title}
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-lg text-white/90 mb-8 max-w-2xl mx-auto"
        >
          {subtitle}
        </motion.p>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Button size="lg" className="bg-white text-primary hover:bg-white/90" asChild>
            <Link to="/admisiones">Proceso de Admisión</Link>
          </Button>
          <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/20 ml-4" asChild>
            <Link to="/contacto">Contáctanos</Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;