import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import SectionHeading from '@/components/SectionHeading';
import { Link } from 'react-router-dom';

const AcademicProgramsSection = ({ programs }) => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <SectionHeading 
          title="Propuesta Académica" 
          subtitle="Enfocados en la Educación Secundaria y la preparación preuniversitaria."
          centered={true}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {programs.map((program, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group"
            >
              <Card className="overflow-hidden border-none shadow-lg card-hover h-full flex flex-col">
                <div className="h-48 overflow-hidden">
                  <img  alt={program.image} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
                </div>
                <div className="flex flex-col flex-grow p-6">
                  <CardHeader className="p-0 mb-2">
                    <CardTitle>{program.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0 flex-grow">
                    <p className="text-gray-600 mb-4">{program.description}</p>
                  </CardContent>
                  <Button variant="outline" className="mt-auto w-full" asChild>
                    <Link to="/academico">Ver detalles</Link>
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
        <div className="text-center mt-12">
          <Button size="lg" asChild>
            <Link to="/academico">
              Descubre Todos Nuestros Programas
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default AcademicProgramsSection;